package com.example.task31c;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

public class EndActivity extends AppCompatActivity {

    TextView nameText;
    TextView score;

    Button newStart;
    Button endButton;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_end);

        nameText = findViewById(R.id.textViewName);
        score = findViewById(R.id.textViewScore);

        newStart = findViewById(R.id.buttonNew);
        endButton = findViewById(R.id.buttonEnd);

        String name = getIntent().getStringExtra("name");
        int getCorrectAnswers = getIntent().getIntExtra("correct", 0);

        nameText.setText("Congratulations: " + (name) + "!");
        score.setText("Your Score: " + (String.valueOf(getCorrectAnswers)) + "/5");

        newStart.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                startActivity(new Intent(EndActivity.this, MainActivity.class));
            }
        });

        endButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                finishAffinity(); //closes everything
                System.exit(0);
            }
        });
    }
}