package com.example.task31c;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.graphics.Color;
import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ListView;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;

import org.w3c.dom.Text;

import java.security.KeyStore;
import java.util.ArrayList;
import java.util.List;

public class QuestionsActivity extends AppCompatActivity {

    TextView textViewWelcome;

    TextView question;
    TextView questions;

    Button option1;
    Button option2;
    Button option3;

    Button submit;
    Button next;

    ProgressBar progressBar;

    String nameSave;

    private List<Questions> questionsList;

    private int currentQuestionPosition = 0;

    private String selectedOptionByUser = "";
    private String selectedOptionByUserCheck = "";

    int progressNumber = 20;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_questions);

        Intent intent = getIntent();
        String name = intent.getStringExtra("name");

        textViewWelcome = findViewById(R.id.textViewWelcome);
        textViewWelcome.setText("Welcome " + name);

        nameSave = name;

        questions = findViewById(R.id.textViewQuestionOne);
        question = findViewById(R.id.textViewQuestionOneQ);

        option1 = findViewById(R.id.buttonOptionOne);
        option2 = findViewById(R.id.buttonOptionTwo);
        option3 = findViewById(R.id.buttonOptionThree);

        submit = findViewById(R.id.buttonSubmit);
        next = findViewById(R.id.buttonNext);

        progressBar = findViewById(R.id.progressBar);

        questionsList = QuestionsArray.getQuestions();

        questions.setText((currentQuestionPosition+1) + "/" + questionsList.size());
        question.setText(questionsList.get(0).getQuestion());
        option1.setText(questionsList.get(0).getOption1());
        option2.setText(questionsList.get(0).getOption2());
        option3.setText(questionsList.get(0).getOption3());

        progressBar.setProgress(progressNumber);

        option1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (selectedOptionByUser.isEmpty()) {
                    selectedOptionByUser = option1.getText().toString();

                    questionsList.get(currentQuestionPosition).setUserSelectedAnswer(selectedOptionByUser);
                    selectedOptionByUserCheck = "Option1";
                }
            }
        });

        option2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (selectedOptionByUser.isEmpty()) {
                    selectedOptionByUser = option2.getText().toString();

                    questionsList.get(currentQuestionPosition).setUserSelectedAnswer(selectedOptionByUser);
                    selectedOptionByUserCheck = "Option2";
                }
            }
        });

        option3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (selectedOptionByUser.isEmpty()) {
                    selectedOptionByUser = option3.getText().toString();

                    questionsList.get(currentQuestionPosition).setUserSelectedAnswer(selectedOptionByUser);
                    selectedOptionByUserCheck = "Option3";
                }
            }
        });

        submit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (selectedOptionByUser.isEmpty()) {
                    Toast.makeText(QuestionsActivity.this, "Please select an option", Toast.LENGTH_SHORT).show();
                }
                else{
                    submitCheckQuestion();
                    next.setVisibility(View.VISIBLE);
                    submit.setVisibility(View.INVISIBLE);
                }
            }
        });

        next.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                changeNextQuestion();
            }
        });
    }

    private void submitCheckQuestion(){
        if (selectedOptionByUserCheck == "Option1")
        {
            option1.setBackgroundTintList(getResources().getColorStateList(R.color.red_test));
            revealAnswer();
        }
        else if (selectedOptionByUserCheck == "Option2")
        {
            option2.setBackgroundTintList(getResources().getColorStateList(R.color.red_test));
            revealAnswer();
        }
        else if (selectedOptionByUserCheck == "Option3")
        {
            option3.setBackgroundTintList(getResources().getColorStateList(R.color.red_test));
            revealAnswer();
        }
    }

    private void changeNextQuestion(){
        currentQuestionPosition += 1;

        submit.setVisibility(View.VISIBLE);
        next.setVisibility(View.INVISIBLE);

        if ((currentQuestionPosition + 1) == questionsList.size()) {
            submit.setText("Submit Quiz");
        }

        if (currentQuestionPosition < questionsList.size()) {
            textViewWelcome.setVisibility(View.INVISIBLE);

            selectedOptionByUser = "";

            option1.setBackgroundTintList(getResources().getColorStateList(R.color.white_test));

            option2.setBackgroundTintList(getResources().getColorStateList(R.color.white_test));

            option3.setBackgroundTintList(getResources().getColorStateList(R.color.white_test));

            questions.setText((currentQuestionPosition+1) + "/" + questionsList.size());
            question.setText(questionsList.get(currentQuestionPosition).getQuestion());
            option1.setText(questionsList.get(currentQuestionPosition).getOption1());
            option2.setText(questionsList.get(currentQuestionPosition).getOption2());
            option3.setText(questionsList.get(currentQuestionPosition).getOption3());

            progressBar.setProgress(progressNumber += 20);
        }
        else{
            Intent intent = new Intent(QuestionsActivity.this, EndActivity.class);
            intent.putExtra("correct", getCorrectAnswers());
            intent.putExtra("incorrect", getIncorrectAnswers());
            intent.putExtra("name", nameSave);
            startActivity(intent);
        }
    }

    private int getCorrectAnswers(){
        int correctAnswers = 0;

        for (int i = 0; i < questionsList.size(); i++){
            String getSelectedAnswer = questionsList.get(i).getSelectedAnswer();
            String getAnswer = questionsList.get(i).getAnswer();

            if (getSelectedAnswer.equals(getAnswer)){
                correctAnswers += 1;
            }
        }
        return correctAnswers;
    }

    private int getIncorrectAnswers() {
        int correctAnswers = 0;

        for (int i = 0; i < questionsList.size(); i++) {
            String getSelectedAnswer = questionsList.get(i).getSelectedAnswer();
            String getAnswer = questionsList.get(i).getAnswer();

            if (!getSelectedAnswer.equals(getAnswer)) {
                correctAnswers += 1;
            }
        }
        return correctAnswers;
    }

    private void revealAnswer() {
        final String getAnswer = questionsList.get(currentQuestionPosition).getAnswer();

        if (option1.getText().toString().equals(getAnswer)) {
            option1.setBackgroundTintList(getResources().getColorStateList(R.color.green_test));
        }
        else if (option2.getText().toString().equals(getAnswer)) {
            option2.setBackgroundTintList(getResources().getColorStateList(R.color.green_test));
        }
        else if (option3.getText().toString().equals(getAnswer)) {
            option3.setBackgroundTintList(getResources().getColorStateList(R.color.green_test));
        }
    }
}