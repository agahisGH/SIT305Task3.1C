package com.example.task31c;

import java.util.ArrayList;
import java.util.List;

public class QuestionsArray {

    private static List<Questions> myQuestions() {

        final List<Questions> questionsLists = new ArrayList<>();

        final Questions question1 = new Questions("What does IDE stand for?", "Integrated Development Environment", "Incredible Development Environment", "Integrated Development Envelope", "Integrated Development Environment", "");
        final Questions question2 = new Questions("Android is ...", "Open Source", "Closed Source", "Medium Source", "Open Source", "");
        final Questions question3 = new Questions("What does SDK stand for?", "Super Development Kit", "Software Development Kit", "Soft Dev Kit", "Software Development Kit", "");
        final Questions question4 = new Questions("Which is NOT a button type in Android", "Button", "Music Button", "Image Button", "Music Button", "");
        final Questions question5 = new Questions("What does API stand for?", "Advanced Programming Interface", "Apps Programmable Interface", "Application Programming Interface", "Application Programming Interface", "");

        questionsLists.add(question1);
        questionsLists.add(question2);
        questionsLists.add(question3);
        questionsLists.add(question4);
        questionsLists.add(question5);

        return questionsLists;
    }

    public static List<Questions> getQuestions() {
        return myQuestions();
    }
}
